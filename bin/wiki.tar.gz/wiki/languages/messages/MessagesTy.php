<?php
/** Tahitian (Reo Mā`ohi)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Sab
 * @author Sainte-Rose (on ty.wikipedia.org)
 * @author Tahitoa (on ty.wikipedia.org)
 */

$fallback = 'fr';

// Remove French aliases
$namespaceGenderAliases = array();

