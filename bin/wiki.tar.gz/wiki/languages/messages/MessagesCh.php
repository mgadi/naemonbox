<?php
/** Chamorro (Chamoru)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$namespaceNames = array(
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Espesiat',
	NS_TALK             => 'Kombetsasion',
	NS_USER             => 'Muna\'sesetbi',
	NS_USER_TALK        => 'Kombetsasion_ni_muna\'sesetbi',
	NS_PROJECT_TALK     => 'Kombetsasion_nu_$1',
	NS_FILE             => 'Litratu',
	NS_FILE_TALK        => 'Kombetsasion_ni_litratu',
	NS_HELP             => 'Ayudo',
	NS_HELP_TALK        => 'Kombetsasion_ni_ayudo',
	NS_CATEGORY         => 'Katigoria',
	NS_CATEGORY_TALK    => 'Kombetsasion_ni_katigoria',
);

