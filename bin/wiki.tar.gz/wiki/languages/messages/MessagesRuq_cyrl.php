<?php
/** Megleno-Romanian (Cyrillic script) (Влахесте)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Andrijko Z.
 * @author Кумулај Маркус
 * @author Макѕе
 * @author Приетен тев
 */

$fallback = 'mk';

