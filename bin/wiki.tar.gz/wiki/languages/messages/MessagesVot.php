<?php
/** Votic (Vaďďa)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author 2Q
 * @author Aig mest ei varasta
 * @author Andrijko Z.
 * @author Comp1089
 * @author Erdemaslancan
 * @author Paivud
 * @author Trần Nguyễn Minh Huy
 */

$fallback = 'fi';

