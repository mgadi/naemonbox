<?php
/** British English (British English)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$specialPageAliases = array(
	'Uncategorizedcategories'   => array( 'UncategorisedCategories' ),
	'Uncategorizedimages'       => array( 'UncategorisedFiles', 'UncategorisedImages' ),
	'Uncategorizedpages'        => array( 'UncategorisedPages' ),
	'Uncategorizedtemplates'    => array( 'UncategorisedTemplates' ),
);

