<?php
/** Maithili (मैथिली)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Amire80
 * @author Ashishanchinhar
 * @author Dhirendra.maithili
 * @author Ggajendra
 * @author Kaganer
 * @author Kapileshwar.raut
 * @author Kumariprity
 * @author Manojberma77
 * @author Meno25
 * @author Nemo bis
 * @author Priyanka.rachna.jha
 * @author Rajesh
 * @author Reedy
 * @author Rillke
 * @author Umeshberma
 * @author Vinitutpal
 */

$fallback = 'hi';

