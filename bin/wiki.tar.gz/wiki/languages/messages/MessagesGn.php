<?php
/** Guarani (Avañe'ẽ)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'es';

$namespaceNames = array(
	NS_SPECIAL          => 'Mba\'echĩchĩ',
	NS_TALK             => 'Myangekõi',
	NS_USER             => 'Puruhára',
	NS_USER_TALK        => 'Puruhára_myangekõi',
	NS_PROJECT_TALK     => '$1_myangekõi',
	NS_FILE             => 'Ta\'ãnga',
	NS_FILE_TALK        => 'Ta\'ãnga_myangekõi',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_myangekõi',
	NS_TEMPLATE         => 'Tembiecharã',
	NS_TEMPLATE_TALK    => 'Tembiecharã_myangekõi',
	NS_HELP             => 'Pytyvõ',
	NS_HELP_TALK        => 'Pytyvõ_myangekõi',
	NS_CATEGORY         => 'Ñemohenda',
	NS_CATEGORY_TALK    => 'Ñemohenda_myangekõi',
);

// Remove Spanish gender aliases (bug 37090)
$namespaceGenderAliases = array();

