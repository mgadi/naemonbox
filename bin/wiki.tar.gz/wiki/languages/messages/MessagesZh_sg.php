<?php
/** Chinese (Singapore) (‪中文(新加坡)‬)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author PhiLiP
 * @author Shizhao
 * @author Wong128hk
 */

# Inherit everything for now
$fallback = 'zh-hans';

