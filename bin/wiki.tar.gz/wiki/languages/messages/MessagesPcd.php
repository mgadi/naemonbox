<?php
/** Picard (Picard)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Geoleplubo
 * @author Hercule
 */

$fallback = 'fr';

// Remove French aliases
$namespaceGenderAliases = array();

