<?php
/** Lower Silesian (Schläsch)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Als-Holder
 * @author Geitost
 * @author Jens Liebenau
 * @author Jonny84
 * @author Kaganer
 * @author Piotron
 * @author Przemub
 * @author Purodha
 * @author Schläsinger
 * @author Teutonius
 * @author The Evil IP address
 * @author Timpul
 * @author Äberlausitzer
 */

$fallback = 'de';

