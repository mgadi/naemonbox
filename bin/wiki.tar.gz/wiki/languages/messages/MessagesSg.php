<?php
/** Sango (Sängö)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Ice201 (on sg.wikipedia.org)
 * @author Mdkidiri
 */

$fallback = 'fr';

// Remove French aliases
$namespaceGenderAliases = array();

