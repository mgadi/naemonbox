<?php
/** لوری (لوری)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Bonevarluri
 * @author Mogoeilor
 */

$rtl = true;

