<?php
/** Nederlands (informeel)‎ (Nederlands (informeel)‎)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author HanV
 * @author MarkvA
 * @author Siebrand
 * @author Tedjuh10
 */

$fallback = 'nl';

