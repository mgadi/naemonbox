<?php
/** Khowar (کھوار)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'ur';
$rtl = true;

$namespaceNames = array(
	NS_MAIN             => '',
	NS_MEDIA            => 'میڈیا',
	NS_SPECIAL          => 'خاص',
	NS_TALK             => 'مشقولگی',
	NS_USER             => 'ممبار/یوزر',
);

