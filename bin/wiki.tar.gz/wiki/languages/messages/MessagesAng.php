<?php
/** Old English (Ænglisc)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$namespaceNames = array(
	NS_SPECIAL          => 'Syndrig',
	NS_TALK             => 'Mōtung',
	NS_FILE             => 'Biliþ',
	NS_FILE_TALK        => 'Biliþmōtung',
	NS_TEMPLATE         => 'Bysen',
	NS_TEMPLATE_TALK    => 'Bysenmōtung',
	NS_HELP             => 'Help',
	NS_HELP_TALK        => 'Helpmōtung',
	NS_CATEGORY         => 'Flocc',
	NS_CATEGORY_TALK    => 'Floccmōtung',
);

$namespaceAliases = array(
	'Gesprec'       => NS_TALK,
	'Brucend'       => NS_USER,
	'Brucendmotung' => NS_USER_TALK,
	'Biliþgesprec'  => NS_FILE_TALK,
	'Bysengesprec'  => NS_TEMPLATE_TALK,
	'Helpgesprec'   => NS_HELP_TALK,
	'Floccgesprec'  => NS_CATEGORY_TALK,
);

