<?php
/** Chinese (China) (‪中文(中国大陆)‬)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Liangent
 * @author PhiLiP
 * @author Shizhao
 * @author Wong128hk
 * @author Xiaomingyan
 */

# Inherit everything for now
$fallback = 'zh-hans';

