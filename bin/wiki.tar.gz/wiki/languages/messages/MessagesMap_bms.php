<?php
/** Basa Banyumasan (Basa Banyumasan)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Bawoor
 * @author Slamet Serayu (on map-bms.wikipedia.org)
 * @author StefanusRA
 * @author לערי ריינהארט
 */

$fallback = 'jv, id';

