<?php
/** Uighur (Uyghurche‎ / ئۇيغۇرچە)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment falls back to Uighur (Arabic script) - ug-arab.
 */

$fallback = 'ug-arab';
