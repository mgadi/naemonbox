<?php
/** Manx (Gaelg)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$namespaceNames = array(
	NS_MEDIA            => 'Meanyn',
	NS_SPECIAL          => 'Er_lheh',
	NS_TALK             => 'Resooney',
	NS_USER             => 'Ymmydeyr',
	NS_USER_TALK        => 'Resooney_ymmydeyr',
	NS_PROJECT_TALK     => 'Resooney_$1',
	NS_FILE             => 'Coadan',
	NS_FILE_TALK        => 'Resooney_coadan',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'Resooney_MediaWiki',
	NS_TEMPLATE         => 'Clowan',
	NS_TEMPLATE_TALK    => 'Resooney_clowan',
	NS_HELP             => 'Cooney',
	NS_HELP_TALK        => 'Resooney_cooney',
	NS_CATEGORY         => 'Ronney',
	NS_CATEGORY_TALK    => 'Resooney_ronney',
);

