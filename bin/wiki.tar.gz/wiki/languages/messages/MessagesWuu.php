<?php
/** Wu (吴语)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Benojan
 * @author Hercule
 * @author O
 * @author Reedy
 * @author Wu-chinese.com
 * @author Xiaomingyan
 * @author Yfdyh000
 * @author 乌拉跨氪
 * @author 十弌
 */

$fallback = 'zh-hans';

