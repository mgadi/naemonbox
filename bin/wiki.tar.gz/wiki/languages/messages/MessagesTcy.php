<?php
/** Tulu (ತುಳು)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author NamwikiTL
 * @author VASANTH S.N.
 * @author VinodSBangera
 */

$fallback = 'kn';

