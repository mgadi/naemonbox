#ifndef NAEMON_BUILDOPTS_H__
#define NAEMON_BUILDOPTS_H__
#define NAEMON_SYSCONFDIR "/etc/naemon"
#define NAEMON_LOCALSTATEDIR "/var/lib/naemon"
#define NAEMON_LOGDIR "/var/log/naemon"
#define NAEMON_LOCKFILE "/var/run/naemon/naemon.pid"
#endif
