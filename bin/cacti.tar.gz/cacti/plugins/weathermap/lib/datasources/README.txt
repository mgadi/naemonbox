Some of these datasource plugins are rather sketchy or even completely non-working.

In particular:
  dbsample doesn't do anything.
  snmp isn't really useful, but has some work done on it.
  external has had no real testing yet
