DROP TABLE IF EXISTS `glpi_plugin_additionalalerts_reminderalerts`;
ALTER TABLE `glpi_plugin_additionalalerts_configs` DROP `delay_reminder`;