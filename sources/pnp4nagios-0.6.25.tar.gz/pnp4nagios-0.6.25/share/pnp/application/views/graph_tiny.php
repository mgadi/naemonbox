<div style="padding:4px">
    <div style="display: table; margin: 0 auto;">
	<table class="body">
	    <tr valign="top">
		<td>
		    <div class="left ui-widget-content ui-corner-all" align="center">
			<?php if (!empty($icon_box)) {
     			    echo $icon_box;
			} ?>

			<?php if (!empty($graph_content)) {
     			    echo $graph_content;
			} ?>
		    </div>
		</td>
	    </tr>
	</table>
    </div>
</div>