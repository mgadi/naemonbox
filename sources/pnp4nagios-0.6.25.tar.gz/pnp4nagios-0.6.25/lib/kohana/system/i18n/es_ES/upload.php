<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'not_writable' => 'El directorio seleccionado, %s, no tiene permisos de escritura.',
);