<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'not_writable' => 'De upload doelmap, %s, is niet schrijfbaar.',
);