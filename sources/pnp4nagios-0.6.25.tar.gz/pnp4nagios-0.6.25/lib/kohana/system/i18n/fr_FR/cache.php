<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'undefined_group'      => 'Le groupe %s n\'est pas défini dans votre configuration.',
    'extension_not_loaded' => 'l\'extension PHP %s doit être chargée pour utiliser ce driver.',
    'unwritable'           => 'Le chemin %s configuré pour le cache n\'est pas accessible en écriture.',
	'resources'            => 'La mise en cache des ressources est impossible car elles n\'ont pas pu être sérialisées.',
	'driver_error'         => '%s'
);
