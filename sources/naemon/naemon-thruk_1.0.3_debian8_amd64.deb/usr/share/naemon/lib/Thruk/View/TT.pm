package Thruk::View::TT;
use parent 'Catalyst::View::TT';

use strict;

=head1 NAME

Thruk::View::TT - TT View for Thruk

=head1 DESCRIPTION

TT View for Thruk.

=head1 AUTHOR

=head1 SEE ALSO

L<Thruk>

Sven Nierlein, 2009-2014, <sven@nierlein.org>

=head1 LICENSE

This library is free software, you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
