// See http://docs.sencha.com/extjs/4.1.1/#!/api/Ext.draw.Sprite
type: "path",
path: "m 130,252.36218 200,0 0,-70 105,105 -105,105 0,-70 -200,0"
