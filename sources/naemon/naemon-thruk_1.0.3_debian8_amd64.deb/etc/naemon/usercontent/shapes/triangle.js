// See http://docs.sencha.com/extjs/4.1.1/#!/api/Ext.draw.Sprite
type: "path",
path: "m 254.28571,375.1242 18.59888,32.21421 18.59888,32.21421 -37.19776,-10e-6 -37.19777,0 18.59889,-32.2142 z"
